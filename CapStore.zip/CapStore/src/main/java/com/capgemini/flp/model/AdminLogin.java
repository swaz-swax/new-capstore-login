package com.capgemini.flp.model;


import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class AdminLogin {
	@Id
	private String emailId;	
	
	private String password;

	
	public AdminLogin() {
		// TODO Auto-generated constructor stub
	}

	public String getEmailId() {
		return emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

	public AdminLogin(String emailId, String password) {
		super();
		this.emailId = emailId;
		this.password = password;
		
	}

	
	
	
	
}
