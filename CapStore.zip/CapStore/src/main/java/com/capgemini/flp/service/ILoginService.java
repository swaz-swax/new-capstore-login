package com.capgemini.flp.service;

import com.capgemini.flp.exception.LoginException;


public interface ILoginService {

	public boolean findUser(String emailId,String password) throws LoginException;
	public boolean findAdmin(String emailId,String password) throws LoginException;
	public boolean findMerchant(String emailId,String password) throws LoginException;

}
